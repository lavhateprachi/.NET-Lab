﻿using Microsoft.Data.SqlClient;
using System.ComponentModel.DataAnnotations;

namespace _230940120130.Models
{
    public class Student
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Enter Student Name")]
        [StringLength(50, MinimumLength = 6, ErrorMessage = "Name should contain at least 6 characters!!!")]
        [DataType(DataType.Text)]
        [Display(Name = "Name")]
        public string? Name { get; set; }

        [Required(ErrorMessage = "Enter Valid Section Number")]
        [Range(1, 10, ErrorMessage = "Range ranges from 1 to 10!!!")]
        [Display(Name = "Section")]
        public int Section { get; set; }

        [Required(ErrorMessage = "Enter Valid Branch Name")]
        [StringLength(50, MinimumLength = 6, ErrorMessage = "Branch should contain at least 6 characters!")]
        [DataType(DataType.Text)]
        [Display(Name = "Branch")]
        public string? Branch { get; set; }


        [Required(ErrorMessage = "Enter Valid Email Address")]
        [StringLength(50, MinimumLength = 6, ErrorMessage = "EmailId should contain at least 6 characters and maximum 50!")]
        [DataType(DataType.Text)]
        [Display(Name = "EmailId")]
        public string? Email { get; set; }


        //Display all student information
        public static List<Student> ViewAllStudents()
        {

            using (SqlConnection cn = new SqlConnection())
            {
                cn.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=StudentDB;Integrated Security=True;";

                List<Student> students = new List<Student>();
                try
                {
                    cn.Open();
                    SqlCommand cmd = cn.CreateCommand();

                    /* Using Text Query */
                    //cmd.CommandType = System.Data.CommandType.Text;
                    //cmd.CommandText = "select * from Student";


                    /* Using Stored Procedure */
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandText = "DisplayAllStudents";

                    SqlDataReader dr = cmd.ExecuteReader();
                    while (dr.Read())
                    {
                        Student std = new Student();

                        std.Id = Convert.ToInt32(dr["StudentNo"]);
                        std.Name = dr["Name"].ToString();
                        std.Section = (int)dr["Section"];
                        std.Branch = dr["Branch"].ToString();
                        std.Email = dr["EmailId"].ToString();

                        students.Add(std);
                    }

                    dr.Close();
                    return students;
                }
                catch (Exception ex)
                {
                    throw ex;
                }

            }
        }

        //Get information of single student which is required in EDIT
        //get student details using student id
        public static Student GetSingleStudent(int id)
        {
            using (SqlConnection cn = new SqlConnection())
            {
                cn.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=StudentDB;Integrated Security=True;";
                Student std = new Student();


                try
                {

                    cn.Open();
                    SqlCommand cmd = cn.CreateCommand();
                    cmd.CommandType = System.Data.CommandType.Text;
                    cmd.CommandText = "select * from Student where StudentNo=@StudentNo";
                    cmd.Parameters.AddWithValue("@StudentNo", id);
                    SqlDataReader dr = cmd.ExecuteReader();
                    if (dr.Read())
                    {

                        std.Id = Convert.ToInt32(dr["StudentNo"]);
                        std.Name = dr["Name"].ToString();
                        std.Section = (int)dr["Section"];
                        std.Branch = dr["Branch"].ToString();
                        std.Email = dr["EmailId"].ToString();


                    }

                    dr.Close();
                    return std;
                }
                catch (Exception ex)
                {
                    throw;
                }

            }
        }


        //update student information using student id 
        public static void updateStudentDetails(int id, Student student)
        {
            using (SqlConnection cn = new SqlConnection())
            {
                cn.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=StudentDB;Integrated Security=True;";
                Student std = new Student();
                try
                {
                    cn.Open();
                    SqlCommand cmd = cn.CreateCommand();

                    /* Using Text Query */
                    //cmd.CommandType = System.Data.CommandType.Text;
                    //cmd.CommandText = "update Student set Name=@Name,Section=@Section,Branch=@Branch,EmailId=@EmailId where StudentNo=@StudentNo";


                    /* Using Stored Procedure */
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandText = "UpdateStudentInformation";

                    cmd.Parameters.AddWithValue("@StudentNo", id);
                    cmd.Parameters.AddWithValue("@Name", student.Name);
                    cmd.Parameters.AddWithValue("@Section", student.Section);
                    cmd.Parameters.AddWithValue("@Branch", student.Branch);
                    cmd.Parameters.AddWithValue("@EmailId", student.Email);

                    cmd.ExecuteNonQuery();

                }
                catch (Exception ex)
                {
                    throw;
                }

            }
        }
    }
}
