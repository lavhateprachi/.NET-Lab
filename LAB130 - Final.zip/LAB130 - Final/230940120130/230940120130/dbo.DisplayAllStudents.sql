﻿CREATE PROCEDURE [dbo].[DisplayAllStudents]
	
AS
	SELECT * FROM STUDENT;
RETURN 0
