﻿CREATE PROCEDURE [dbo].[UpdateStudentInformation]

	@StudentNo int,
	@Name varchar(50),
	@Section int,
	@Branch varchar(50),
	@EmailId varchar(50)
AS
	update student set Name=@Name,Section=@Section,Branch=@Branch,EmailId=@EmailId where StudentNo=@StudentNo;
RETURN 0
