﻿CREATE TABLE [dbo].[Student]
(
	[StudentNo] INT NOT NULL PRIMARY KEY identity,
	[Name] varchar(50),
	[Section] int,
	[Branch] varchar(50),
	[EmailId] varchar(50)
)
